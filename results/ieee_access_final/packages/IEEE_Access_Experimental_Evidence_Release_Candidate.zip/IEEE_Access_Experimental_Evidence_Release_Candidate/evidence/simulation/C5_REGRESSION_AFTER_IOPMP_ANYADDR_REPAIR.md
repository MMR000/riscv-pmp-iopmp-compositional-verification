# C.5 regression after any-address IOPMP repair

## Binary

Rebuilt via `scripts/run/run_m7_ibex_c5_build.sh`. Both RST-A/B trees hash-match production IOPMP:

`dd7fe6a89f22a9c830615528733b2d51ccfb852ca0966d3991ab1172d06c82c8`

## IF01-A (independent events)

- 1× `DMA_ADMITTED`
- 1× `ARB_DMA_GNT`
- 1× `SRAM_WRITE SRC=DMA`
- No `DUPLICATE_SRAM_WRITE`
- Harness `RES=0x600d00c1`

## Full suite (`run_m7_phase_c5_tests.py`)

- All IF01–IF03 / STALE cases: PASS (no FAIL lines)
- ORD-A..H × RST-A/B: all PASS
- Random release-order (200 seeds): PASS (no FAIL lines)

Logs: `simulation/c5_full_regression.log`, `simulation/IF01_A_*.log`
