#!/usr/bin/env bash
# Pin tools/z3 4.13.4 and record GNU time + SBY summaries. Does not edit properties.
set -euo pipefail
ROOT=/home/mmr/ricv_paper
OUT="$ROOT/results/m7/evidence_cleanup/formal"
mkdir -p "$OUT"
export PATH="$ROOT/tools/z3/bin:$PATH"
SBY=(python3 "$ROOT/tools/SymbiYosys/sbysrc/sby.py")

{
  echo "UTC=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "which_z3=$(command -v z3)"
  echo "z3_version=$(z3 --version)"
  echo "yosys_version=$(yosys -V | head -1)"
  echo "sby_version=$("${SBY[@]}" --version 2>&1 | tr '\n' ' ')"
  echo "sby_path=${SBY[*]}"
  sha256sum "$ROOT/tools/z3/bin/z3"
} | tee "$OUT/TOOL_VERSIONS.txt"

run_one() {
  local name="$1"
  local sby="$2"
  local workdir="$3"
  echo "=== $name ==="
  mkdir -p "$OUT/$name"
  cp -a "$sby" "$OUT/$name/config.sby"
  (
    cd "$workdir"
    /usr/bin/time -v "${SBY[@]}" -f -d "$OUT/$name/sby" "$(basename "$sby")" \
      >"$OUT/$name/sby_stdout.txt" 2>"$OUT/$name/gnu_time.txt"
  ) || true
  echo "exit recorded for $name"
}

run_one sp08_rstb_prove \
  "$ROOT/formal/sby/sp08_rstb_prove.sby" \
  "$ROOT/formal/sby"

run_one prod_arbiter_v2_prove \
  "$ROOT/IEEE_Access_End_to_End_Authorization_Proof_Closure/formal/configurations/prod_arbiter_v2_prove.sby" \
  "$ROOT/IEEE_Access_End_to_End_Authorization_Proof_Closure/formal/configurations"

run_one noregrant_any_prove \
  "$ROOT/IEEE_Access_Any_Address_Regrant_Repair_and_Proof/formal/configurations/noregrant_any_prove.sby" \
  "$ROOT/IEEE_Access_Any_Address_Regrant_Repair_and_Proof/formal/configurations"

echo "ALL_FORMAL_DONE"
