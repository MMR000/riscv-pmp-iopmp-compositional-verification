# Access-2026-41377 experimental-evidence release candidate

Manuscript: IEEE Access **Access-2026-41377**.  
Freeze date: 2026-09-24.  
Git commit recorded at freeze: `07ee8931f8e7e75d48168914fffddb31a5e0a091` (branch `exactly-once-sound-verification`).  
This directory is an audit freeze. It does **not** develop RTL and does **not** edit the manuscript.

Supersedes `IEEE_Access_Final_Experimental_Evidence.zip` (`510684cb7ff9dea2bcc6bda297779e8e22af54d1e7323f5483b140e920b01619`, 2026-09-21), which predates the any-address IOPMP repair.

## What this candidate contains

1. `tables/SOURCE_PROVENANCE_MATRIX.csv` — major formal, simulation, and PPA results → exact RTL hashes and build configuration.
2. `tables/PROOF_STATISTICS.csv` — SP-08, ARB-1–ARB-10 (one cone), and any-address no-regrant, extracted from original logs. Missing fields are marked `NOT_RECORDED`.
3. `tables/CLAIM_TO_ARTIFACT.csv` — included paths, reproduction commands, expected outputs, measured runtimes, PDK/OpenROAD requirements.
4. `tables/IF01_A_TRANSACTION_LEDGER.csv` plus `tables/C5_REGRESSION_RESULTS.csv`. Historical failures and inconclusive results are in `tables/HISTORICAL_FAILURES_AND_INCONCLUSIVE.csv`.
5. `reports/OPTION_A_AND_J2_J3_SCOPE.md` — Option A readiness architecture and exact J2/J3 synthesis scope.

Discrepancies: `reports/MISSING_OR_INCONSISTENT_EVIDENCE.md`.  
Proposed tag (not created): `PROPOSED_GITHUB_TAG.txt`.

## Frozen production RTL at this freeze

| File | SHA-256 |
|------|---------|
| `rtl/iopmp/iopmp.v` | `dd7fe6a89f22a9c830615528733b2d51ccfb852ca0966d3991ab1172d06c82c8` |
| `m7/rtl/m7_research_arbiter.sv` | `204776349008176d2cc2934c0304a27497302cfbe522011ff9358dadf81b4519` |

Formal ARB/no-regrant tasks used a staged Verilog copy of the arbiter (`m7_research_arbiter.v`, SHA-256 `4ee4c3fdcc42c536e68817b546d71975efa911b627571d3748568b4d7da3f7a5`) that adds `ifdef FORMAL` observation ports. That file is **not** byte-identical to the production `.sv`.

## Verification

```bash
bash reproduction/VERIFY.sh
```

The script re-hashes referenced source ZIPs (if present next to the repo root), checks included-file SHA-256 against `SHA256SUMS` (that file is excluded from its own digest), and checks that every path in the claim table exists.

Do **not** push, tag, or publish without approval.
