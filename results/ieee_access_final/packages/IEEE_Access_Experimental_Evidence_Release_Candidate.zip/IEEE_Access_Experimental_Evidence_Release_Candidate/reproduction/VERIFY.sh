#!/usr/bin/env bash
# Re-verify included-file digests and referenced source ZIPs. Does not re-run formal/sim/PPA.
set -euo pipefail
RC="$(cd "$(dirname "$0")/.." && pwd)"
REPO="$(cd "$RC/.." && pwd)"
fail=0

echo "== included SHA256SUMS (excludes SHA256SUMS itself) =="
if [[ ! -f "$RC/SHA256SUMS" ]]; then
  echo "MISSING $RC/SHA256SUMS" >&2
  exit 1
fi
(
  cd "$RC"
  sha256sum -c SHA256SUMS
) || fail=1

echo
echo "== source ZIP checksums (if present at repo root) =="
while read -r hash name; do
  [[ "$hash" =~ ^# ]] && continue
  [[ -z "${hash:-}" ]] && continue
  path="$REPO/$name"
  if [[ ! -f "$path" ]]; then
    echo "ABSENT  $name"
    continue
  fi
  got="$(sha256sum "$path" | awk '{print $1}')"
  if [[ "$got" == "$hash" ]]; then
    echo "OK      $name"
  else
    echo "MISMATCH $name expected $hash got $got" >&2
    fail=1
  fi
done < "$RC/evidence/source_packages/SOURCE_ZIP_SHA256.txt"

echo
echo "== claim-table included paths =="
python3 - "$RC" <<'PY'
import csv, sys
from pathlib import Path
rc = Path(sys.argv[1])
missing = []
with (rc / "tables" / "CLAIM_TO_ARTIFACT.csv").open() as f:
    for row in csv.DictReader(f):
        for token in [t.strip() for t in row["included_path"].split(";")]:
            token = token.split()[0] if token else ""
            if not token:
                continue
            fp = rc / token
            if not fp.exists():
                missing.append((row["claim_id"], token))
if missing:
    for cid, tok in missing:
        print(f"MISSING {cid}: {tok}")
    sys.exit(1)
print("OK      all CLAIM_TO_ARTIFACT included_path files exist")
PY

echo
echo "== production RTL hashes =="
exp_iopmp=dd7fe6a89f22a9c830615528733b2d51ccfb852ca0966d3991ab1172d06c82c8
exp_arb=204776349008176d2cc2934c0304a27497302cfbe522011ff9358dadf81b4519
got_iopmp="$(sha256sum "$REPO/rtl/iopmp/iopmp.v" | awk '{print $1}')"
got_arb="$(sha256sum "$REPO/m7/rtl/m7_research_arbiter.sv" | awk '{print $1}')"
[[ "$got_iopmp" == "$exp_iopmp" ]] && echo "OK      rtl/iopmp/iopmp.v" || { echo "MISMATCH iopmp.v" >&2; fail=1; }
[[ "$got_arb" == "$exp_arb" ]] && echo "OK      m7/rtl/m7_research_arbiter.sv" || { echo "MISMATCH arbiter.sv" >&2; fail=1; }

if [[ "$fail" -ne 0 ]]; then
  echo "VERIFY FAILED" >&2
  exit 1
fi
echo
echo "VERIFY OK"
