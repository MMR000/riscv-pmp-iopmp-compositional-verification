// V2 (corrected assumption hygiene):
// - A0: environment (no traffic during reset/warmup)
// - A4: RECLASSIFIED as environment request-hold protocol, NOT a DUT assertion.
//   Evidence: free-input BMC CE shows registered gnt observable with req already
//   deasserted (formal/proofs/prod_arbiter_v2_bmc A4-as-assert FAIL). Production
//   masters (m7_ibex_data_adapter, Ibex data_req_o until gnt; IOPMP dma_req_out
//   while pending) hold request until grant is accepted.
// - A5: DISCHARGED — asserted and proved (grant mutual exclusion).
// - Ghost scoreboard captures from parallel input samples at rising grant; under
//   A4-ENV those samples align with the DUT capture edge.
`include "bus_pkg.vh"
`include "formal_helpers.vh"

module formal_prod_arbiter_tb (
    input wire clk,
    input wire rst_n,
    input wire cpu_req,
    input wire [`ADDR_WIDTH-1:0] cpu_addr,
    input wire cpu_write,
    input wire [`DATA_WIDTH-1:0] cpu_wdata,
    input wire dma_req,
    input wire [`ADDR_WIDTH-1:0] dma_addr,
    input wire dma_write,
    input wire [`DATA_WIDTH-1:0] dma_wdata
);
    `FORMAL_RESET_CTRL(clk, dut_rst_n, formal_warmup)

    wire cpu_gnt, cpu_valid, dma_gnt, dma_valid;
    wire [`DATA_WIDTH-1:0] cpu_rdata, dma_rdata;
    wire norm_req, norm_write, norm_gnt, norm_valid;
    wire [`ADDR_WIDTH-1:0] norm_addr;
    wire [`DATA_WIDTH-1:0] norm_wdata, norm_rdata;
    wire prot_req, prot_write, prot_gnt, prot_valid;
    wire [`ADDR_WIDTH-1:0] prot_addr;
    wire [`DATA_WIDTH-1:0] prot_wdata, prot_rdata;
    wire [1:0] f_state;
    wire       f_serve_cpu;
    wire       f_target_issued;
    wire [`ADDR_WIDTH-1:0] f_a_addr;
    wire                   f_a_write;
    wire [`DATA_WIDTH-1:0] f_a_wdata;

    m7_research_arbiter u_ic (
        .clk(clk), .rst_n(dut_rst_n),
        .cpu_req(cpu_req), .cpu_addr(cpu_addr), .cpu_write(cpu_write), .cpu_wdata(cpu_wdata),
        .cpu_gnt(cpu_gnt), .cpu_valid(cpu_valid), .cpu_rdata(cpu_rdata),
        .dma_req(dma_req), .dma_addr(dma_addr), .dma_write(dma_write), .dma_wdata(dma_wdata),
        .dma_gnt(dma_gnt), .dma_valid(dma_valid), .dma_rdata(dma_rdata),
        .norm_req(norm_req), .norm_addr(norm_addr), .norm_write(norm_write), .norm_wdata(norm_wdata),
        .norm_gnt(norm_gnt), .norm_valid(norm_valid), .norm_rdata(norm_rdata),
        .prot_req(prot_req), .prot_addr(prot_addr), .prot_write(prot_write), .prot_wdata(prot_wdata),
        .prot_gnt(prot_gnt), .prot_valid(prot_valid), .prot_rdata(prot_rdata),
        .f_state(f_state), .f_serve_cpu(f_serve_cpu), .f_target_issued(f_target_issued),
        .f_a_addr(f_a_addr), .f_a_write(f_a_write), .f_a_wdata(f_a_wdata)
    );

    sram #(.DEPTH(256)) u_norm (
        .clk(clk), .rst_n(dut_rst_n),
        .req(norm_req), .write(norm_write), .addr(norm_addr), .wdata(norm_wdata),
        .gnt(norm_gnt), .valid(norm_valid), .rdata(norm_rdata),
        .mem_changed(), .changed_addr(), .changed_wdata(),
        .peek_addr(`ADDR_NORMAL_SRAM_BASE), .peek_data()
    );
    sram #(.DEPTH(256)) u_prot (
        .clk(clk), .rst_n(dut_rst_n),
        .req(prot_req), .write(prot_write), .addr(prot_addr), .wdata(prot_wdata),
        .gnt(prot_gnt), .valid(prot_valid), .rdata(prot_rdata),
        .mem_changed(), .changed_addr(), .changed_wdata(),
        .peek_addr(`ADDR_PROTECT_SRAM_BASE), .peek_data()
    );

    localparam S_IDLE = 2'd0, S_MEM = 2'd1;

    // -------- Environment assumptions ONLY --------
    // A0: no traffic during reset/warmup
    always @(*) assume (formal_warmup || (!cpu_req && !dma_req));
    // A4_ENV: request-hold protocol of legal masters (adapter / IOPMP forward path).
    // NOT a DUT output guarantee — see A4-as-assert CE under free inputs.
    always @(*) assume (!cpu_gnt || cpu_req);
    always @(*) assume (!dma_gnt || dma_req);
    // NOTE: A5 is NOT assumed — asserted below.

    wire check = formal_warmup && dut_rst_n;

    reg cpu_gnt_q, dma_gnt_q;
    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) begin cpu_gnt_q<=0; dma_gnt_q<=0; end
        else begin cpu_gnt_q<=cpu_gnt; dma_gnt_q<=dma_gnt; end
    end
    wire admit_cpu = check && cpu_gnt && !cpu_gnt_q;
    wire admit_dma = check && dma_gnt && !dma_gnt_q;
    wire admit_evt = admit_cpu || admit_dma;

    wire tgt_write_evt = check && prot_req && prot_write;
    wire tgt_read_evt  = check && prot_req && !prot_write;

    // Parallel input sample (same NBA edge as DUT capture under A4_ENV)
    reg [`ADDR_WIDTH-1:0] cpu_addr_s, dma_addr_s;
    reg cpu_write_s, dma_write_s;
    reg [`DATA_WIDTH-1:0] cpu_wdata_s, dma_wdata_s;
    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) begin
            cpu_addr_s<=0; dma_addr_s<=0; cpu_write_s<=0; dma_write_s<=0;
            cpu_wdata_s<=0; dma_wdata_s<=0;
        end else begin
            cpu_addr_s<=cpu_addr; dma_addr_s<=dma_addr;
            cpu_write_s<=cpu_write; dma_write_s<=dma_write;
            cpu_wdata_s<=cpu_wdata; dma_wdata_s<=dma_wdata;
        end
    end

    // Prior-cycle request samples for temporal DUT obligation (grant ↔ sampled req)
    reg cpu_req_d, dma_req_d;
    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) begin cpu_req_d<=0; dma_req_d<=0; end
        else begin cpu_req_d<=cpu_req; dma_req_d<=dma_req; end
    end

    reg        sb_live, sb_is_cpu, sb_write, sb_prot;
    reg [`ADDR_WIDTH-1:0] sb_addr;
    reg [`DATA_WIDTH-1:0] sb_wdata;
    reg        sb_tgt_write_seen, sb_resp_seen;

    wire match_live_write = sb_live && sb_write && sb_prot &&
                            (prot_addr == sb_addr) && (prot_wdata == sb_wdata) &&
                            (f_serve_cpu == sb_is_cpu);

    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) begin
            sb_live <= 0; sb_tgt_write_seen <= 0; sb_resp_seen <= 0;
            sb_is_cpu <= 0; sb_write <= 0; sb_prot <= 0;
            sb_addr <= 0; sb_wdata <= 0;
        end else if (check) begin
            if (admit_evt) begin
                sb_live <= 1;
                sb_is_cpu <= admit_cpu;
                sb_write <= admit_cpu ? cpu_write_s : dma_write_s;
                sb_addr  <= admit_cpu ? cpu_addr_s  : dma_addr_s;
                sb_wdata <= admit_cpu ? cpu_wdata_s : dma_wdata_s;
                sb_prot  <= admit_cpu ? `IN_PROT(cpu_addr_s) : `IN_PROT(dma_addr_s);
                sb_tgt_write_seen <= 0;
                sb_resp_seen <= 0;
            end
            if (tgt_write_evt && match_live_write)
                sb_tgt_write_seen <= 1;
            if (sb_live && ((sb_is_cpu && cpu_valid) || (!sb_is_cpu && dma_valid)))
                sb_resp_seen <= 1;
            if (sb_live && sb_resp_seen && (f_state == S_IDLE) && !tgt_write_evt && !admit_evt)
                sb_live <= 0;
        end
    end

    reg [1:0] f_state_q;
    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) f_state_q <= S_IDLE;
        else f_state_q <= f_state;
    end
    reg f_target_issued_q;
    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) f_target_issued_q <= 0;
        else f_target_issued_q <= f_target_issued;
    end

    // ===== A5 discharged as DUT assertion (was circular assume) =====
    always @(posedge clk) begin
        if (check) assert(!(cpu_gnt && dma_gnt));
    end

    // A4_DUT_TEMPORAL: rising grant corresponds to a request present on the
    // preceding cycle (covers registered-gnt observability without same-cycle
    // forcing). Under A4_ENV, same-cycle also holds; this remains as DUT check.
    always @(posedge clk) begin
        if (admit_cpu) assert(cpu_req_d || cpu_req);
        if (admit_dma) assert(dma_req_d || dma_req);
    end

    // ARB-1
    always @(posedge clk) begin
        if (check && (f_state_q == S_MEM)) assert(!(cpu_gnt || dma_gnt));
        if (check && (cpu_gnt || dma_gnt)) assert(f_state_q == S_IDLE);
    end

    // ARB-2: capture == parallel-sampled inputs at rising grant
    always @(posedge clk) begin
        if (admit_cpu) begin
            assert(f_serve_cpu);
            assert(f_state == S_MEM);
            assert(f_a_addr == cpu_addr_s);
            assert(f_a_write == cpu_write_s);
            assert(f_a_wdata == cpu_wdata_s);
        end
        if (admit_dma) begin
            assert(!f_serve_cpu);
            assert(f_state == S_MEM);
            assert(f_a_addr == dma_addr_s);
            assert(f_a_write == dma_write_s);
            assert(f_a_wdata == dma_wdata_s);
        end
    end

    // ARB-3
    always @(posedge clk) begin
        if (check && (f_state == S_MEM) && sb_live && !admit_evt) begin
            assert(f_a_addr == sb_addr);
            assert(f_a_write == sb_write);
            assert(f_a_wdata == sb_wdata);
            assert(f_serve_cpu == sb_is_cpu);
        end
    end

    // ARB-4
    always @(posedge clk) begin
        if (check && prot_req) assert(`IN_PROT(f_a_addr));
        if (check && norm_req) assert(`IN_NORM(f_a_addr));
    end

    // ARB-5 / 5b
    always @(posedge clk) begin
        if (tgt_write_evt && match_live_write) assert(!sb_tgt_write_seen);
        if (tgt_write_evt) assert(match_live_write);
    end

    // ARB-6
    always @(posedge clk) begin
        if (check && prot_req) begin
            assert(prot_addr == f_a_addr);
            assert(prot_write == f_a_write);
            assert(prot_wdata == f_a_wdata);
        end
    end

    // ARB-7 / 8
    always @(posedge clk) begin
        if (check && cpu_valid && sb_live) assert(sb_is_cpu && f_serve_cpu);
        if (check && dma_valid && sb_live) assert(!sb_is_cpu && !f_serve_cpu);
        if (check && sb_live && cpu_valid && sb_is_cpu) assert(!sb_resp_seen);
        if (check && sb_live && dma_valid && !sb_is_cpu) assert(!sb_resp_seen);
    end

    // ARB-9: target issue at most once per admission
    always @(posedge clk) begin
        if (check && f_target_issued && f_target_issued_q && (f_state == S_MEM) && !admit_evt)
            assert(!(prot_req || norm_req));
    end

    // ARB-10: no grant while serving
    always @(posedge clk) begin
        if (check && (f_state == S_MEM) && !admit_evt)
            assert(!(cpu_gnt || dma_gnt));
    end

    // Non-vacuity covers
    always @(posedge clk) begin
        cover(check && admit_cpu && sb_write && sb_prot);
        cover(check && admit_dma && sb_write && sb_prot);
        cover(check && tgt_write_evt && sb_is_cpu);
        cover(check && tgt_write_evt && !sb_is_cpu);
        cover(check && tgt_read_evt);
        cover(check && cpu_req && dma_req);
        cover(check && cpu_valid);
        cover(check && dma_valid);
    end
endmodule
