# IEEE_Access_Final_Evidence_Cleanup

Engineering-only cleanup on top of frozen baseline
`IEEE_Access_Experimental_Evidence_Release_Candidate.zip`
SHA-256 `67d82af4705cd9f8f19564f6c22ce60cd6e8647bfd561c8f40184d50e240f486`.

No manuscript, LaTeX, PDF, or publication prose.

Contents:

- `formal/` pinned SP-08 RST-B, ARB-1–10 v2, any-address no-regrant (logs, src, PASS, gnu_time; solver intermediates omitted)
- `simulation/` IF01-A / IF02-A / IF03-C / IF03-D reruns after monitor/reporting fixes
- `historical/` original IF02-A SCOREBOARD_FAIL and empty-err IF03-C/D logs
- `ppa/` J2/J3 `FLOW_VARIANT=final_dd7fe6` sky130hd 20 ns
- `arbiter_diff/` formal-vs-production arbiter compare
- `tables/` CSV engineering tables
- `reproduction/` commands and tool versions
- `SOURCE_HASHES.txt`, `SHA256SUMS`

Do not tag, push, or publish from this package.
