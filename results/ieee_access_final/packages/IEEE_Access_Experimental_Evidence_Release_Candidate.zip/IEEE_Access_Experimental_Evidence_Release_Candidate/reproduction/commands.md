# Reproduction commands (from the source packages; not re-run in this freeze)

Formal tools used historically: Yosys 0.68+ (conda-forge sha1 832843ad0-dirty), SymbiYosys `tools/SymbiYosys/sbysrc/sby.py` (version string unknown), Z3 **intended** `tools/z3/bin/z3` 4.13.4. Do not use conda Z3 5.0.0 unless you are reproducing a PATH snapshot that recorded it.

```bash
export PATH="$PWD/tools/z3/bin:$PATH"
z3 --version    # must print 4.13.4 for the Resubmission/any-address intended path

# SP-08
python3 tools/SymbiYosys/sbysrc/sby.py -f -d OUT/sp08_reset formal/sby/sp08_reset.sby
python3 tools/SymbiYosys/sbysrc/sby.py -f -d OUT/sp08_rstb_prove formal/sby/sp08_rstb_prove.sby

# ARB cone
python3 tools/SymbiYosys/sbysrc/sby.py -f -d \
  IEEE_Access_End_to_End_Authorization_Proof_Closure/formal/proofs/prod_arbiter_v2_prove \
  IEEE_Access_End_to_End_Authorization_Proof_Closure/formal/configurations/prod_arbiter_v2_prove.sby

# Any-address no-regrant
bash IEEE_Access_Any_Address_Regrant_Repair_and_Proof/reproduction/REPRODUCE.sh

# C.5 (after C.5 rebuild with production IOPMP/arbiter)
python3 scripts/analysis/run_m7_phase_c5_tests.py \
  --sim-a results/m7/realcore_reset_c5/rsta/sim-verilator/Vm7_ibex_c5_composed_top \
  --sim-b results/m7/realcore_reset_c5/rstb/sim-verilator/Vm7_ibex_c5_composed_top \
  --out-dir results/m7/realcore_reset_c5 \
  --matrix-dir results/m7/realcore_reset_c5/tables \
  --random-n 200

# J2/J3 repaired PPA (Docker; host openroad ABSENT)
FLOW_VARIANT=repaired_exact_once CLOCK_PERIOD=20.0 \
  bash scripts/ppa/run_orfs_m7_docker.sh J2 LOG
FLOW_VARIANT=repaired_exact_once CLOCK_PERIOD=20.0 \
  bash scripts/ppa/run_orfs_m7_docker.sh J3 LOG
```

PDK: sky130hd via `openroad/orfs@sha256:817b608c69a71fafc7b61baec11b4dc073fb8efb9d2714f9bd3316db4beba277`. Not redistributed here.

This freeze only **copies and audits** existing logs. It does not re-execute the experiments.
