# POST_REPAIR_PPA

## Provenance

| Variant | Instantiates repaired arbiter? | Historical post-route stdcell area (ORIGINAL arbiter) | Repaired measurement |
|---------|--------------------------------|------------------------------------------------------|----------------------|
| J0 | No | 157366 | Not re-run (unaffected hierarchy) |
| J1 | No | 241200 | Not re-run |
| J2 | **Yes** (`m7_research_arbiter`) | **279752** | **278827** (this package) |
| J3 | **Yes** | **280749** | See log / metrics when complete |

Historical source: `results/tables/m7_full_ibex_ppa_20ns.csv` (sky130hd, 20 ns, ORFS image digest `817b608c…`).

Do **not** attribute historical J2/J3 numbers to the repaired RTL.

## Environment

- Host `openroad`: ABSENT
- Docker daemon: OK
- Image: `openroad/orfs@sha256:817b608c69a71fafc7b61baec11b4dc073fb8efb9d2714f9bd3316db4beba277`
- `FLOW_VARIANT=repaired_exact_once`, `CLOCK_PERIOD=20.0`
- Arbiter SHA-256: `204776349008176d2cc2934c0304a27497302cfbe522011ff9358dadf81b4519`

## J2 repaired results (finish + GDS)

| Metric | Value |
|--------|------:|
| Synth cells | 28661 |
| Synth area | 242178.52 |
| Post-route stdcell area (µm²) | **278827** |
| Core area | 482094 |
| Utilization | 0.578 |
| Setup WNS (ns) | 1.20544 |
| Setup TNS | 0 |
| Hold WNS (ns) | 0.376382 |
| Hold TNS | 0 |
| Timing | PASS |
| Route DRC | 0 |
| Wirelength | 1340772 |
| GDS | YES (`6_final.gds`) |
| Result | PASS |

JSON: `physical_design/j2_repaired_metrics.json`

Δ area vs historical original J2: 278827 − 279752 = **−925 µm²** (−0.33%). Same PDK/image/period; RTL differs by the exact-once arbiter flip-flop. Treat as matched repaired measurement, not a claim that historical rows are invalid.

## J3

See `physical_design/logs/j3_repaired_20ns.log` and updated provenance CSV when the run completes.

## Notes

- First docker session ended after `5_2_route.odb`; finish was resumed successfully (`j2_repaired_20ns_finish.log`). `make report` is not an ORFS target (exit 2 after finish already produced metrics).

## J3 repaired results (finish + GDS)

| Metric | Value |
|--------|------:|
| Synth cells | 27759 |
| Post-route stdcell area (µm²) | **277934** |
| Core area | 479567 |
| Setup WNS (ns) | 1.10692 |
| Hold WNS (ns) | 0.0716267 |
| Timing | PASS |
| Route DRC | 0 |
| Wirelength | 1360867 |
| GDS | YES |
| Result | PASS |
| Wall time | 1207 s |

JSON: `physical_design/j3_repaired_metrics.json`

Δ area vs historical original J3: 277934 − 280749 = **−2815 µm²** (−1.00%).
