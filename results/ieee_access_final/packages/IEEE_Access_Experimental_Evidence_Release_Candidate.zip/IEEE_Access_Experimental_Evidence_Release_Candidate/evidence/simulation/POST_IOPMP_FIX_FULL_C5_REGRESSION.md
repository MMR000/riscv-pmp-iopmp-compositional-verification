# POST_IOPMP_FIX_FULL_C5_REGRESSION

## Binary provenance

Repaired IOPMP `ec77c2a9…` + arbiter `20477634…` + independent SRAM monitor.

See `simulation/c5_full_regression/binary_source_hashes.txt`.

## Results (summary)

| Suite | Outcome |
|-------|---------|
| IF01-A | **PASS** — 1 admit / 1 arb grant / 1 independent SRAM write |
| IF01-B/C/D, IF02, IF03, STALE-01 | PASS (see matrix) |
| ORD-A..H × RST-A/B | all PASS |
| Random release-order (50 seeds) | PASS |

Matrices: `simulation/c5_full_regression/tables/`.

## Handshake checks exercised by IF/ORD

Grant delayed by target delay=8; completion after SRAM write; DMA reset mid-flight (IF01); IOPMP/sec reset (IF01-D); back-to-back not showing duplicate on repaired path.

## Performance

No claim that fewer writes equal higher throughput. Historical J2/J3 remain **arbiter-scoped** (`20477634…`); IOPMP change does not transfer those numbers to a new full-chip PPA without a matched experiment (not run this round — arbiter hash unchanged).
