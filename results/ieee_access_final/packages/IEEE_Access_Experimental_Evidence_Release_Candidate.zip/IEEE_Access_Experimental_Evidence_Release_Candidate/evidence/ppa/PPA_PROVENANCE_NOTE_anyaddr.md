# PPA provenance note

Synthesizable IOPMP changed (`ec77c2a9…` → `dd7fe6a89f22a9…`): withdraw `dma_req_out` on grant observe.

- **J2/J3 OpenROAD measurements** remain scoped to the **arbiter** hierarchy recorded previously and are **unchanged** (arbiter hash still `20477634…`).
- They do **not** automatically characterize the new IOPMP cell area/timing.
- No OpenROAD re-run this round (IOPMP-only handshake change; user policy: reassess, re-run PPA when claiming new IOPMP physical numbers).
- Claiming updated full-system or IOPMP PPA requires a new matched physical-design experiment.
