// Sound IOPMP no-regrant formal harness (monitor-only ledger).
// Scope modes via `defines:
//   SCOPE_PROT   — constrain DMA address into protected SRAM (security-relevant)
//   SCOPE_ANY    — unconstrained address (exposes miss-path re-grant)
// No gnt_cnt==0 gating of the safety property: the second grant itself fails.
`include "bus_pkg.vh"
`include "formal_helpers.vh"

module formal_iopmp_noregrant_tb (
    input wire clk,
    input wire rst_n,
    input wire enable,
    input wire dma_req,
    input wire [`ADDR_WIDTH-1:0] dma_addr,
    input wire dma_write,
    input wire [`DATA_WIDTH-1:0] dma_wdata,
    input wire [7:0] dma_requester_id,
    input wire [15:0] dma_length,
    input wire [`ADDR_WIDTH-1:0] rule0_base,
    input wire [`ADDR_WIDTH-1:0] rule0_limit,
    input wire [7:0] rule0_rid,
    input wire rule0_re,
    input wire rule0_we,
    input wire rule0_valid,
    input wire cpu_req
);
    `FORMAL_RESET_CTRL(clk, dut_rst_n, formal_warmup)

    wire dma_gnt, dma_valid, dma_error;
    wire [`DATA_WIDTH-1:0] dma_rdata;
    wire dma_req_out, dma_write_out;
    wire [`ADDR_WIDTH-1:0] dma_addr_out;
    wire [`DATA_WIDTH-1:0] dma_wdata_out;
    wire bus_gnt, bus_valid;
    wire [`DATA_WIDTH-1:0] bus_rdata;
    wire txn_valid, txn_auth;
    wire [7:0] txn_rid;
    wire [`ADDR_WIDTH-1:0] txn_addr;
    wire txn_write;
    wire hold_auth, hold_write;
    wire [7:0] hold_rid;
    wire [`ADDR_WIDTH-1:0] hold_addr;

    iopmp u_iopmp (
        .clk(clk), .rst_n(dut_rst_n), .enable(enable),
        .dma_req(dma_req), .dma_addr(dma_addr), .dma_write(dma_write),
        .dma_wdata(dma_wdata), .dma_requester_id(dma_requester_id),
        .dma_length(dma_length),
        .dma_gnt(dma_gnt), .dma_valid(dma_valid), .dma_rdata(dma_rdata),
        .dma_error(dma_error),
        .dma_req_out(dma_req_out), .dma_addr_out(dma_addr_out),
        .dma_write_out(dma_write_out), .dma_wdata_out(dma_wdata_out),
        .bus_gnt(bus_gnt), .bus_valid(bus_valid), .bus_rdata(bus_rdata),
        .rule0_base(rule0_base), .rule0_limit(rule0_limit),
        .rule0_rid(rule0_rid), .rule0_re(rule0_re), .rule0_we(rule0_we),
        .rule0_valid(rule0_valid),
        .secure_ready(1'b1), .security_epoch(8'd0),
        .txn_valid(txn_valid), .txn_master(), .txn_addr(txn_addr), .txn_write(txn_write),
        .txn_authorized_at_admission(txn_auth),
        .txn_requester_id(txn_rid), .txn_length(), .txn_age(), .busy(),
        .f_state(),
        .f_hold_authorized(hold_auth),
        .f_hold_rid(hold_rid),
        .f_hold_addr(hold_addr),
        .f_hold_write(hold_write)
    );

    wire cpu_gnt, cpu_valid;
    wire [`DATA_WIDTH-1:0] cpu_rdata;
    wire prot_req, prot_write, prot_gnt, prot_valid;
    wire [`ADDR_WIDTH-1:0] prot_addr;
    wire [`DATA_WIDTH-1:0] prot_wdata, prot_rdata;
    wire norm_req, norm_write, norm_gnt, norm_valid;
    wire [`ADDR_WIDTH-1:0] norm_addr;
    wire [`DATA_WIDTH-1:0] norm_wdata, norm_rdata;
    wire [1:0] f_state;
    wire f_serve_cpu, f_target_issued;
    wire [`ADDR_WIDTH-1:0] f_a_addr;
    wire f_a_write;
    wire [`DATA_WIDTH-1:0] f_a_wdata;

    m7_research_arbiter u_ic (
        .clk(clk), .rst_n(dut_rst_n),
        .cpu_req(1'b0), .cpu_addr(32'h0), .cpu_write(1'b0), .cpu_wdata(32'h0),
        .cpu_gnt(cpu_gnt), .cpu_valid(cpu_valid), .cpu_rdata(cpu_rdata),
        .dma_req(dma_req_out), .dma_addr(dma_addr_out),
        .dma_write(dma_write_out), .dma_wdata(dma_wdata_out),
        .dma_gnt(bus_gnt), .dma_valid(bus_valid), .dma_rdata(bus_rdata),
        .norm_req(norm_req), .norm_addr(norm_addr), .norm_write(norm_write), .norm_wdata(norm_wdata),
        .norm_gnt(norm_gnt), .norm_valid(norm_valid), .norm_rdata(norm_rdata),
        .prot_req(prot_req), .prot_addr(prot_addr), .prot_write(prot_write), .prot_wdata(prot_wdata),
        .prot_gnt(prot_gnt), .prot_valid(prot_valid), .prot_rdata(prot_rdata),
        .f_state(f_state), .f_serve_cpu(f_serve_cpu), .f_target_issued(f_target_issued),
        .f_a_addr(f_a_addr), .f_a_write(f_a_write), .f_a_wdata(f_a_wdata)
    );

    sram #(.DEPTH(256)) u_prot (
        .clk(clk), .rst_n(dut_rst_n),
        .req(prot_req), .write(prot_write), .addr(prot_addr), .wdata(prot_wdata),
        .gnt(prot_gnt), .valid(prot_valid), .rdata(prot_rdata),
        .mem_changed(), .changed_addr(), .changed_wdata(),
        .peek_addr(`ADDR_PROTECT_SRAM_BASE), .peek_data()
    );
    sram #(.DEPTH(256)) u_norm (
        .clk(clk), .rst_n(dut_rst_n),
        .req(norm_req), .write(norm_write), .addr(norm_addr), .wdata(norm_wdata),
        .gnt(norm_gnt), .valid(norm_valid), .rdata(norm_rdata),
        .mem_changed(), .changed_addr(), .changed_wdata(),
        .peek_addr(`ADDR_NORMAL_SRAM_BASE), .peek_data()
    );

    // ---- Monitor ledger (not used to weaken the assert) ----
    reg                     admit_live;
    reg                     grant_seen;      // sticky until admit retires
    reg                     write_seen;      // sticky prot write for this admit
    reg                     dma_req_out_q;
    reg [`ADDR_WIDTH-1:0]   env_addr;
    reg                     env_write;
    reg [`DATA_WIDTH-1:0]   env_wdata;
    reg [7:0]               env_rid;
    reg                     env_auth;
    reg [`ADDR_WIDTH-1:0]   snap_addr;
    reg                     snap_write;
    reg [`DATA_WIDTH-1:0]   snap_wdata;
    reg [7:0]               snap_rid;
    reg [7:0]               admit_id;
    reg [7:0]               grant_id;

    wire check = formal_warmup && dut_rst_n;
    wire genuine_admit = dma_gnt && txn_valid && txn_auth;

    always @(posedge clk or negedge dut_rst_n) begin
        if (!dut_rst_n) begin
            admit_live <= 0;
            grant_seen <= 0;
            write_seen <= 0;
            dma_req_out_q <= 0;
            snap_addr <= 0; snap_write <= 0; snap_wdata <= 0; snap_rid <= 0;
            env_addr <= 0; env_write <= 0; env_wdata <= 0; env_rid <= 0; env_auth <= 0;
            admit_id <= 0; grant_id <= 0;
        end else begin
            dma_req_out_q <= dma_req_out;
            if (dma_req) begin
                snap_addr  <= dma_addr;
                snap_write <= dma_write;
                snap_wdata <= dma_wdata;
                snap_rid   <= dma_requester_id;
            end
            if (genuine_admit) begin
                admit_live <= 1'b1;
                grant_seen <= 1'b0;
                write_seen <= 1'b0;
                env_addr  <= snap_addr;
                env_write <= snap_write;
                env_wdata <= snap_wdata;
                env_rid   <= snap_rid;
                env_auth  <= 1'b1;
                admit_id  <= admit_id + 8'd1;
            end
            // Capture grant identity; sticky until retirement (do NOT clear on bus_valid alone
            // before checking a same-cycle late grant — retirement clears after assert window).
            if (bus_gnt && admit_live) begin
                grant_seen <= 1'b1;
                grant_id   <= admit_id;
            end
            if (prot_req && prot_write && !f_serve_cpu && admit_live)
                write_seen <= 1'b1;
            // Retire only after completion and after grant_seen has been observed for a full cycle
            // when a grant occurred; always retire on dma_valid.
            if (dma_valid)
                admit_live <= 1'b0;
        end
    end

    // Environment
    always @(*) assume (formal_warmup || !dma_req);
    always @(*) assume (!cpu_req);
    always @(*) assume (enable);
    always @(*) assume (rule0_base == `ADDR_PROTECT_SRAM_BASE);
    always @(*) assume (rule0_limit == `ADDR_PROTECT_SRAM_LIMIT);
    always @(*) assume (rule0_valid && rule0_we && rule0_re);
    always @(*) assume (rule0_rid == 8'h01);
    always @(*) assume (dma_length == 16'd0 || dma_length == 16'd4);
    always @(*) assume (dma_requester_id == 8'h01);
`ifdef SCOPE_PROT
    // Security-relevant scope: protected-region DMA only.
    always @(*) assume (!dma_req || `IN_PROT(dma_addr));
`endif
`ifdef FORCE_OOM
    // Force out-of-map address (reproduces historical 0x80010000-class miss path)
    always @(*) assume (!dma_req || (!`IN_PROT(dma_addr) && !`IN_NORM(dma_addr)));
`endif
`ifdef FORCE_NORM
    always @(*) assume (!dma_req || `IN_NORM(dma_addr));
`endif
    always @(posedge clk) begin
        if (check && $past(dma_req) && dma_req && !dma_gnt) begin
            assume (dma_addr == $past(dma_addr));
            assume (dma_write == $past(dma_write));
            assume (dma_wdata == $past(dma_wdata));
            assume (dma_requester_id == $past(dma_requester_id));
        end
    end

    // IOPMP-2: grant only if IOPMP presented this or prior cycle (registered grant)
    always @(posedge clk) begin
        if (check && bus_gnt)
            assert (dma_req_out || dma_req_out_q);
    end

    // IOPMP-3: second distinct arbiter acceptance under the same live admission → FAIL.
    // Uses $past(grant_seen) so the FIRST grant (which sets grant_seen via NBA) is allowed,
    // while any later grant while admit_live with prior grant_seen fails immediately.
    always @(posedge clk) begin
        if (check && bus_gnt && admit_live && $past(grant_seen) && $past(admit_live))
            assert (1'b0);
    end

    // IOPMP-4: after a grant has been seen for this admit, do not re-present
    // a fresh request before completion (req may still be high the grant-observe cycle).
    always @(posedge clk) begin
        if (check && admit_live && $past(grant_seen) && $past(admit_live) && !dma_valid)
            assert (!(dma_req_out && !dma_req_out_q)); // no rising req after grant
    end

    // IOPMP-5: payload correspondence on grant
    always @(posedge clk) begin
        if (check && bus_gnt && admit_live) begin
            assert (dma_addr_out == env_addr);
            assert (dma_write_out == env_write);
            assert (dma_wdata_out == env_wdata);
            assert (env_auth);
            assert (hold_rid == env_rid);
        end
    end

    // IOPMP-7: at most one protected target-write pulse per admission
    always @(posedge clk) begin
        if (check && prot_req && prot_write && !f_serve_cpu && admit_live && $past(write_seen) && $past(admit_live))
            assert (1'b0);
    end

    always @(posedge clk) begin
        // Non-vacuity: at least one grant and one clean completion under the safety cone
        cover (check && bus_gnt && admit_live && env_write);
        cover (check && dma_valid && $past(grant_seen) && !$past(bus_gnt));
`ifdef FORCE_OOM
        cover (check && bus_gnt && admit_live && !`IN_PROT(env_addr) && !`IN_NORM(env_addr));
        cover (check && bus_valid && $past(bus_gnt));
`endif
`ifdef FORCE_NORM
        cover (check && bus_gnt && admit_live && `IN_NORM(env_addr));
`endif
`ifdef SCOPE_PROT
        cover (check && bus_gnt && admit_live && `IN_PROT(env_addr));
        cover (check && prot_req && prot_write && !f_serve_cpu && admit_live);
`endif
`ifndef FORCE_OOM
`ifndef FORCE_NORM
`ifndef SCOPE_PROT
        cover (check && bus_gnt && admit_live && `IN_PROT(env_addr));
        cover (check && bus_gnt && admit_live && `IN_NORM(env_addr));
        cover (check && bus_gnt && admit_live && !`IN_PROT(env_addr) && !`IN_NORM(env_addr));
`endif
`endif
`endif
    end
endmodule
